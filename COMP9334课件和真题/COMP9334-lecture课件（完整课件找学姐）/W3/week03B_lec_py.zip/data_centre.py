#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
COMP9334, Week 3B Lecture 

Data centre example
"""

import numpy as np 
import matplotlib.pyplot as plt 

# Aims: 
# (1) To compute the probability that exactly k machines are operating 
# (2) To compute the probability that at least k machines are operating 

# Constants for the problem 
M = 120        # Number of machines
MTTF = 500     # Mean-time-to-failure in minutes
MRT = 20       # Mean repair time in minutes

# The arrival and departure rates of the queueing problem 
lamb = 1/MTTF    # Arrival rate of failed machines
mu = 1/MRT        # Service rate of failed machines 

# We will use different number of staff 
# N is used to denote the number of staff 
staff_numbers = [2, 5, 10]     # Number of repair staff can be 2, 5 or 10

# Calculate P(k) using the formula in the lecture notes 
# Method: Assume P(0)=1 and then compute P(1), P(2), ..., P(M).  
# Normalise to get probability. 
# 
prob_k_working = {}  
prob_at_least_k_working = {}  
for N in staff_numbers:  # N = number of staff 
    # p[k] = Prob k machines failed 
    # p[k] is un-normalised version of P(k) in the lecture notes 
    p = np.zeros((M+1,))     
    p[0] = 1 # Initislise P(0) = 1 
    for k in range(1,M+1): # Calculate P(1) to P(M) 
        if k <= N:
            p[k] = p[k-1]*(lamb*(M-k+1))/(mu*k)
        else:
            p[k] = p[k-1]*(lamb*(M-k+1))/(mu*N)
            
    # Normalise the array to get probability 
    p = p / sum(p)
 
    # Reverse the array to get probability of exactly k machines working
    p_working = np.flipud(p)
 
    # Store the results in the dictionary for prob_k_working
    prob_k_working[str(N)] = p_working

    # Probability that at least k machines are working
    prob_at_least_k_working[str(N)] = np.flipud(np.cumsum(np.flipud(p_working)))

# Plot the results 
array_k = np.arange(0,M+1)  # Number of working machines 

plt.figure()
plt.plot(array_k,prob_k_working['2'],'bx',label='N = 2')
plt.plot(array_k,prob_k_working['5'],'gd',label='N = 5')
plt.plot(array_k,prob_k_working['10'],'ro',label='N = 10')
plt.legend()
plt.grid()
plt.xlabel('Number of machines in operation [k]')
plt.ylabel('Probability that exactly k machine works')
plt.savefig('dcex1.png')

plt.figure()
plt.plot(array_k,prob_at_least_k_working['2'],'bx',label='N = 2')
plt.plot(array_k,prob_at_least_k_working['5'],'gd',label='N = 5')
plt.plot(array_k,prob_at_least_k_working['10'],'ro',label='N = 10')
plt.legend()
plt.grid()
plt.xlabel('Number of machines in operation [k]')
plt.ylabel('Probability that at least k machine works')
plt.savefig('dcex2.png')

