#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
COMP9334 Week 3B, Question 2

"""

import numpy as np 
import matplotlib.pyplot as plt

# To determine the factor by which the CPU must be sped up
# in order to reduce the response time to 0.65 minute per 
# transaction

# We use the code in cpu_speedup.m and put it in a for-loop 

# We will do this a range of values of speed up factor k 
num_speed_up_factors = 21  # number of speed up factors to try 
array_speed_up_factor = np.linspace(1,2,num_speed_up_factors)    # k from 1 to 2 with step size of 0.05 

# initialisatipn
system_throughput = np.zeros((num_speed_up_factors,))
response_time = np.zeros((num_speed_up_factors,))

# for each value of speed up factor, find  the response time
for i in range(num_speed_up_factors):
    k = array_speed_up_factor[i]
    
    # The steady state probability is the solution to
    # A x = b
    # where A and b are the following matrices
    # The elemens of x is 
    # x = [P(2,0,0) P(1,1,0) P(1,0,1) P(0,2,0) P(0,1,1) P(0,0,2)]
    # 
    A = np.array([ [6*k,      -4,        -2,   0,   0,   0],
                   [-3*k,  6*k+4,         0,  -4,  -2,   0],
                   [-3*k,      0,     6*k+2,   0,  -4,  -2],
                   [0,      -3*k,         0,   4,   0,   0],
                   [0,      -3*k,      -3*k,   0,   6,   0],
                   [1,         1,         1,   1,   1,   1]  ])
    b = np.array([0, 0, 0, 0, 0, 1])
    x = np.linalg.solve(A,b)
    
    # The throughput in transactions per minute is
    # 6*k*(P(2,0,0)+P(1,1,0)+P(1,0,1))
    # =6*k*(x[0]+x[1]+x[2])
    system_throughput[i] = 6*k*(sum(x[:3]))
    
    # The response time is
    response_time[i] = 2 / system_throughput[i]

# Plot response time against speed up factor k     
plt.plot(array_speed_up_factor,response_time)
plt.xlabel('Speed up factor of CPU')
plt.ylabel('response time (in minutes)')
plt.grid()
plt.savefig('speed_up.png')